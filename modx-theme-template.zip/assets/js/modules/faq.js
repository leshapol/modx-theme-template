// ======================================
// FAQ Accordion
// ======================================

function initFaq() {
  const items = document.querySelectorAll(".faq__item");
  if (!items.length) return;

  items.forEach((item) => {
    const btn = item.querySelector(".faq__question");
    const content = item.querySelector(".faq__answer");

    if (!btn || !content) return;

    btn.addEventListener("click", () => {
      const isOpen = item.classList.contains("open");

      // Close all
      items.forEach((i) => i.classList.remove("open"));

      // Toggle current
      if (!isOpen) {
        item.classList.add("open");
      }
    });
  });
}
