// ======================================
// Projects Slider
// ======================================

function initProjectsSlider() {
  const slider = document.querySelector(".projects");
  if (!slider) return;

  const items = slider.querySelectorAll(".projects__item");
  const nextBtn = slider.querySelector(".projects__next");
  const prevBtn = slider.querySelector(".projects__prev");

  let index = 0;

  function update() {
    items.forEach((item, i) => {
      item.classList.toggle("active", i === index);
    });
  }

  if (nextBtn) {
    nextBtn.addEventListener("click", () => {
      index = (index + 1) % items.length;
      update();
    });
  }

  if (prevBtn) {
    prevBtn.addEventListener("click", () => {
      index = (index - 1 + items.length) % items.length;
      update();
    });
  }

  update();
}
