// ======================================
// Reviews Slider
// ======================================

function initReviewsSlider() {
  const slider = document.querySelector(".reviews");
  if (!slider) return;

  const items = slider.querySelectorAll(".reviews__item");
  const nextBtn = slider.querySelector(".reviews__next");
  const prevBtn = slider.querySelector(".reviews__prev");

  let index = 0;

  function update() {
    items.forEach((item, i) => {
      item.classList.toggle("active", i === index);
    });
  }

  if (nextBtn) {
    nextBtn.addEventListener("click", () => {
      index = (index + 1) % items.length;
      update();
    });
  }

  if (prevBtn) {
    prevBtn.addEventListener("click", () => {
      index = (index - 1 + items.length) % items.length;
      update();
    });
  }

  update();
}
